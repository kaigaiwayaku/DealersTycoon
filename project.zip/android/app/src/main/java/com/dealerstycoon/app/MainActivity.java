package com.dealerstycoon.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
