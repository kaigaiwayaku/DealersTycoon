# ディーラーズタイクーン(アプリ版)

- アプリID:com.dealerstycoon.app
- アプリ名:ディーラーズタイクーン
- 中身:`www/`(ゲーム本体・フォント。完全オフラインで動きます)
- 作り:Capacitor 7(iPhone/iPad=`ios/`、Android=`android/`)

## 最初に一度だけ(Mac / Windows 共通)
1. Node.js(LTS版)を入れる:https://nodejs.org/
2. このフォルダで次を実行
   ```
   npm install
   npx cap sync
   ```

## iPhone / iPad(Mac が必要)
1. Xcode を App Store から入れる
2. `npx cap open ios`(または `ios/App/App.xcodeproj` をダブルクリック)
3. 左の「App」→「Signing & Capabilities」→ Team に自分の Apple ID を選ぶ
4. 上の端末選択で iPhone をつないで ▶ を押すと、実機に入ります
5. ストアに出すとき:メニュー「Product」→「Archive」→「Distribute App」
   (Apple Developer Program への登録が必要)

## Android(Windows / Mac どちらでも)
1. Android Studio を入れる:https://developer.android.com/studio
2. `npx cap open android`(または Android Studio で `android` フォルダを開く)
3. スマホをUSBでつなぎ(開発者オプションの「USBデバッグ」をオン)▶ を押す
4. 試し用の APK:メニュー「Build」→「Build App Bundle(s) / APK(s)」→「Build APK(s)」
5. ストアに出すとき:「Build」→「Generate Signed App Bundle」で .aab を作り、Google Play Console へ
   (Google Play デベロッパー登録が必要)

## ゲームを更新したとき
新しい `www/index.html` に差し替えて `npx cap sync` を実行するだけです。
